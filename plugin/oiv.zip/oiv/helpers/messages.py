"""all string messages in the plugin"""
from qgis.PyQt.QtWidgets import QMessageBox  # pylint: disable=import-error


def showMsgBox(msgName, extraBody=''):
    msgSettings = MESSAGES[msgName]
    if msgSettings["type"] == 'information':
        return QMessageBox.information(None, msgSettings["header"], msgSettings["body"] + extraBody, QMessageBox.Ok)
    if msgSettings["type"] == 'warning':
        return QMessageBox.warning(None, msgSettings["header"], msgSettings["body"] + extraBody)
    if msgSettings["type"] == 'critical':
        return QMessageBox.critical(None, msgSettings["header"], msgSettings["body"] + extraBody)
    if msgSettings["type"] == 'question':
        reply = QMessageBox.warning(None, msgSettings["header"], msgSettings["body"] + extraBody, QMessageBox.Yes, QMessageBox.No)
        if reply == QMessageBox.Yes:
            return True
        return False
    if msgSettings["type"] == 'question_save':
        reply = QMessageBox.warning(None, msgSettings["header"], msgSettings["body"] + extraBody, QMessageBox.Save, QMessageBox.Discard)
        if reply == QMessageBox.Save:
            return True
        return False

#All messages
MESSAGES = {
    'verdieping_bestaat_al': {
        "type": 'question',
        "header":'Er bestaan al verdiepingen!',
        "body":'Op minimaal één van de verdiepingen bestaat al een verdieping.\nHet gaat om de volgende verdieping(en):\n'
    },
    'gridcreated': {
        "type": 'information',
        "header":'Het grid is succesvol aangemaakt!',
        "body":'Het grid is succesvol aangemaakt!'
    },
    'nochoice': {
        "type": 'information',
        "header":'Geen keuze gemaakt',
        "body":'Selecteer eerst een actie die u wilt uitvoeren!'
    },
    'deletegrid': {
        "type": 'question',
        "header": 'Continue?',
        "body": 'Weet u zeker dat u het bestaande grid wilt weggooien?'
    },
    'selectgrid': {
        "type": 'information',
        "header": 'Selecteer grid!',
        "body": 'Selecteer het grid dat u wilt weggooien op de kaart.'
    },
    'nogridselected': {
        "type": 'information',
        "header": 'Geen tekenlaag!',
        "body": 'U heeft geen grid of kaartblad aangeklikt!\n\nKlik a.u.b. op de juiste locatie.'
    },
    'deleteobject_question': {
        "type": 'question',
        "header": 'Continue?',
        "body": 'Weet u zeker dat u de geselecteerde feature wilt weggooien?'
    },
    'noselectedtodelete': {
        "type": 'information',
        "header": 'Geen tekenlaag!',
        "body": 'U heeft geen feature op een tekenlaag aangeklikt!\n\nKlik a.u.b. op de juiste locatie.'
    },
    'bouwlaagcreated': {
        "type": 'information',
        "header": 'Gereed!',
        "body": 'Alle verdiepingen zijn succesvol aangemaakt!'
    },
    'nobouwlaagselected': {
        "type": 'information',
        "header": 'Geen verdieping!',
        "body": 'U heeft geen verdieping aangeklikt!\n\nKlik a.u.b. op de juiste locatie.'
    },
    'importchecksok': {
        "type": 'information',
        "header": 'Checks ok!',
        "body": 'Alle checks uitgevoerd u kunt doorgaan met importeren!'
    },
    'importerrorrdstelsel': {
        "type": 'warning',
        "header": 'Geen RD stelsel!',
        "body": 'Het coordinatenstelsel is geen RD!<br><br>\
                 Pas dit aan voordat je verder gaat met inlezen!'
    },
    'importerrorgeometrie': {
        "type": 'warning',
        "header": 'Geometrie komt niet overeen!',
        "body": 'De geometrie in het bestand komt niet overeen met de geselecteerde laag!<br><br>'
                'Pas dit aan voordat je verder gaat met inlezen!'
    },
    'importsuccesfull': {
        "type": 'information',
        "header": 'Gereed!',
        "body": 'Alle feature zijn succesvol geimporteerd!'
    },
    'importpartiallysuccesfull': {
        "type": 'information',
        "header": 'Gereed!',
        "body": 'Features zijn geimporteerd.\n'
                'Aantal features dat niet is geïmporteerd vanwege ongeldige geometrie: '
    },
    'bouwlaagvolgorde': {
        "type": 'warning',
        "header": 'Let op!',
        "body": 'De hoogste verdieping kan niet lager zijn als de laagste, vul opnieuw in!.'
    },
    'noidentifiedobject': {
        "type": 'information',
        "header": 'Geen tekenlaag!',
        "body": 'U heeft geen feature op een tekenlaag aangeklikt!\n\nKlik a.u.b. op de juiste locatie.'
    },
    'invalidgeometry': {
        "type": 'warning',
        "header": 'Ongeldige geometrie!',
        "body": 'Vermoedelijk heeft u 2x op hetzelfde punt geklikt of doorkruist de geometrie zichzelf.\n\n'
                'De geometrie wordt niet opgeslagen.'
    },
    'noparentfeature': {
        "type": 'warning',
        "header": 'Let op!',
        "body": 'Geen object gevonden om aan te koppelen.\n\n'
                'Zorg dat het te koppelen object in het kaartbeeld zichtbaar is.'
    },
    'nofeature': {
        "type": 'warning',
        "header": 'Let op!',
        "body": 'Geen feature gevonden.\n\n'
                'Geen feature gevonden in de betreffende kaartlaag.'
    },
    'invaliddatabaseversion': {
        "type": 'critical',
        "header": 'Let op!',
        "body": 'De plugin of het project komt niet overeen met database versie!\n'
                'Vraag aan uw regionaal beheerder om een database update.\n\n'
                'Excuses voor het ongemak.'
    },
    'unsavedchanges': {
        "type": 'question_save',
        "header": 'Niet opgeslagen wijzigingen!',
        "body": 'Om van verdieping te veranderen moet u eerst de bewerkingen opslaan!\n\nIn de volgende laag zijn nog niet opgeslagen wijzigingen: '
    },
    'no_objectid': {
        "type": 'critical',
        "header": 'Geen object ID!',
        "body": 'Er is geen object ID gevonden. Ga terug naar het beginscherm van de plugin en selecteer het object opnieuw!'
    },
    'wronglayeridentified': {
        "type": 'information',
        "header": 'Verkeerde laag!',
        "body": 'U heeft op de verkeerde laag geklikt!\n\nKlik a.u.b. op de juiste locatie.'
    },
    'print_finished': {
        "type": 'information',
        "header": 'Printen afgerond!',
        "body": 'Het printen is gereed.\n\nU kunt de bestanden vinden in:\n'
    },
    'print_canceld': {
        "type": 'warning',
        "header": 'Printen',
        "body": 'Het printen is geannuleerd.\n\nBestand is open of beveiligd en kan niet worden overschreven!\n\nSluit het eerst en probeer dan opnieuw.'
    },
    'multipleBouwlagenidentified': {
        "type": 'warning',
        "header": 'Meerdere verdiepingen',
        "body": 'Er zijn meerdere verdiepingen die elkaar overlapppen.\nDus het is onduidelijk waaraan u wilt koppelen.\nHerstel dit eerst.'
    },
    'modifyHistory': {
        "type": 'question',
        "header": 'OIV',
        "body": 'Heeft u de historie bijgewerkt?'        
    },
    'fileAlreadyExists': {
        "type": 'question',
        "header": 'Let op!',
        "body": 'Bestand bestaat al, wilt u het bestand overschrijven?'
    },
    'werkvoorraad_conflict_overgeslagen': {
        "type": 'warning',
        "header": 'Conflict niet afgehandeld',
        "body": 'Er staan 1 of meerdere conflicten in de werkvoorraad.\nDeze moeten handmatig afgehandeld worden.'
    },
    'werkvoorraad_meerdere_conflicten': {
        "type": 'warning',
        "header": 'Conflict één tegelijk',
        "body": 'Conflicten kunnen alleen één voor één afgehandeld worden.\nSelecteer één conflict en ga verder.'
    },
}
